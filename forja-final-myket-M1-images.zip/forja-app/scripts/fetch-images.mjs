console.log("FORJA uses local bundled images in public/images; no remote image download is required.");

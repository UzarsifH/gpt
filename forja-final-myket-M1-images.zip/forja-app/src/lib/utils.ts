import { toEnDigits } from "@/lib/format";

export {
  faNum,
  toEnDigits,
  formatToman,
  bmiOf,
  bmiLabel,
  calcBmr,
  ageFromRange,
} from "@/lib/format";

export function normalizePhone(input: string) {
  let s = toEnDigits(input || "").trim().replace(/[\s\-()]/g, "");
  if (s.startsWith("+98")) s = `0${s.slice(3)}`;
  else if (s.startsWith("0098")) s = `0${s.slice(4)}`;
  else if (s.startsWith("98") && s.length === 12) s = `0${s.slice(2)}`;
  else if (/^9\d{9}$/.test(s)) s = `0${s}`;
  return s;
}

export function isValidPhone(s: string) {
  return /^09\d{9}$/.test(s);
}

function bytesToHex(bytes: Uint8Array) {
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}

function hexToBytes(hex: string) {
  const out = new Uint8Array(hex.length / 2);
  for (let i = 0; i < out.length; i++) out[i] = parseInt(hex.slice(i * 2, i * 2 + 2), 16);
  return out;
}

export function randomHex(byteLen = 16) {
  const bytes = new Uint8Array(byteLen);
  if (typeof crypto !== "undefined" && crypto.getRandomValues) {
    crypto.getRandomValues(bytes);
  } else {
    for (let i = 0; i < byteLen; i++) bytes[i] = Math.floor(Math.random() * 256);
  }
  return bytesToHex(bytes);
}

const ITERATIONS = 60000;

async function pbkdf2(password: string, saltHex: string) {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", hash: "SHA-256", salt: hexToBytes(saltHex) as BufferSource, iterations: ITERATIONS },
    key,
    256,
  );
  return bytesToHex(new Uint8Array(bits));
}

/** هش ساده برای حالتی که WebCrypto در دسترس نیست (مثلاً باز کردن روی http در شبکه) */
function fallbackHash(password: string, saltHex: string) {
  let h1 = 0xdeadbeef;
  let h2 = 0x41c6ce57;
  const str = `${saltHex}:${password}`;
  for (let i = 0; i < str.length; i++) {
    const c = str.charCodeAt(i);
    h1 = Math.imul(h1 ^ c, 2654435761);
    h2 = Math.imul(h2 ^ c, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return (h2 >>> 0).toString(16).padStart(8, "0") + (h1 >>> 0).toString(16).padStart(8, "0");
}

const hasSubtle = () => typeof crypto !== "undefined" && !!crypto.subtle && typeof crypto.subtle.deriveBits === "function";

/** فرمت خروجی: `الگوریتم$salt$hash` */
export async function hashPassword(password: string) {
  const salt = randomHex(16);
  if (hasSubtle()) return `pbkdf2$${salt}$${await pbkdf2(password, salt)}`;
  return `fnv$${salt}$${fallbackHash(password, salt)}`;
}

export async function verifyPassword(password: string, stored: string) {
  const [algo, salt, hash] = (stored || "").split("$");
  if (!algo || !salt || !hash) return false;
  if (algo === "pbkdf2") {
    if (!hasSubtle()) return false;
    return (await pbkdf2(password, salt)) === hash;
  }
  if (algo === "fnv") return fallbackHash(password, salt) === hash;
  return false;
}

export function daysFromNow(days: number) {
  return new Date(Date.now() + days * 24 * 60 * 60 * 1000);
}

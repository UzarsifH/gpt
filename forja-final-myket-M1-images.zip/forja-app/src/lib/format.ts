const FA_DIGITS = "۰۱۲۳۴۵۶۷۸۹";

export function faNum(n: number | string) {
  return String(n).replace(/\d/g, (d) => FA_DIGITS[Number(d)] ?? d);
}

export function toEnDigits(input: string) {
  const fa = "۰۱۲۳۴۵۶۷۸۹";
  const ar = "٠١٢٣٤٥٦٧٨٩";
  return input
    .replace(/[۰-۹]/g, (d) => String(fa.indexOf(d)))
    .replace(/[٠-٩]/g, (d) => String(ar.indexOf(d)));
}

export function formatToman(n: number) {
  return `${faNum(n.toLocaleString("en-US"))} تومان`;
}

export function bmiOf(heightCm: number, weightKg: number) {
  const m = heightCm / 100;
  if (m <= 0) return 0;
  return Math.round((weightKg / (m * m)) * 10) / 10;
}

export function bmiLabel(bmi: number) {
  if (bmi < 18.5) return "کم‌وزن";
  if (bmi < 25) return "نرمال";
  if (bmi < 30) return "اضافه‌وزن";
  return "چاقی";
}

export function calcBmr(gender: string, weight: number, height: number, ageApprox: number) {
  const base = 10 * weight + 6.25 * height - 5 * ageApprox;
  return Math.round(gender === "female" ? base - 161 : base + 5);
}

export function ageFromRange(range: string) {
  const map: Record<string, number> = {
    u18: 17,
    "18-25": 22,
    "26-35": 30,
    "36-45": 40,
    "46-55": 50,
    "55p": 58,
  };
  return map[range] ?? 28;
}

export function formatDuration(sec: number) {
  const m = Math.floor(sec / 60);
  const s = sec % 60;
  return `${faNum(m)}:${faNum(String(s).padStart(2, "0"))}`;
}

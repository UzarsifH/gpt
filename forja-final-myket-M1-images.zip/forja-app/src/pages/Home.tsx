import { useEffect, useState } from "react";
import { useRouter } from "@/lib/nav";
import { IMG } from "@/lib/media";
import { RippleButton, useAuth } from "@/components/Providers";

const tips = [
  "عضله در باشگاه تخریب می‌شود و در آشپزخانه و خواب ساخته می‌شود.",
  "اگر آخرین تکرار تمیز نیست، وزنه سنگین‌تر افتخار نیست.",
  "پا را حذف نکن. هورمون رشد عاشق اسکوات است.",
  "آب کم یعنی تمرین ضعیف. قبل از گرسنگی، تشنگی را بکش.",
  "پیشرفت یعنی این هفته یک تکرار بیشتر از هفته قبل.",
];

export default function HomePage() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [tip] = useState(() => tips[new Date().getDate() % tips.length]);
  const hour = new Date().getHours();
  const greet = hour < 12 ? "صبح بخیر" : hour < 18 ? "وقت تمرین" : "شب آهنی";

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [loading, user, router]);

  if (loading || !user) {
    return <div className="p-6"><div className="shimmer h-48 rounded-3xl" /></div>;
  }

  return (
    <div className="px-4 pb-6 pt-8">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs text-[var(--muted)]">{greet}</p>
          <h1 className="text-2xl font-extrabold">{user.name || "قهرمان"}</h1>
        </div>
        <img src={IMG.logo} alt="" className="h-11 w-11 rounded-2xl" />
      </div>

      <div className="relative mt-5 overflow-hidden rounded-[28px] fade-up" style={{ height: 220 }}>
        <img src={IMG.athleteRed} alt="" className="hero-img h-full w-full" />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent" />
        <div className="absolute bottom-4 right-4 left-4">
          <span className="chip">مربی اختصاصی</span>
          <h2 className="mt-2 text-xl font-extrabold">بدن تو، برنامه تو</h2>
          <p className="mt-1 text-xs text-white/70">۴ هفته طراحی‌شده روی هدف و ضعف‌هات</p>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-3 gap-2 fade-up-d1">
        {[
          { n: user.isPremium ? "فعال" : "آزاد", l: "وضعیت" },
          { n: user.hasPlan ? "۴ هفته" : "نمونه", l: "برنامه" },
          { n: user.isPremium ? "VIP" : "پایه", l: "سطح باشگاه" },
        ].map((s) => (
          <div key={s.l} className="card p-3 text-center">
            <div className="text-sm font-extrabold text-[var(--lime)]">{s.n}</div>
            <div className="mt-1 text-[10px] text-[var(--muted)]">{s.l}</div>
          </div>
        ))}
      </div>

      <div className="card mt-4 p-4 fade-up-d2">
        <p className="text-xs text-[var(--gold)]">نکته امروز مربی</p>
        <p className="mt-2 text-sm leading-7">{tip}</p>
      </div>

      <div className="mt-5">
        <h3 className="mb-3 text-sm font-bold">مسیر تمرین</h3>
        <div className="grid gap-3">
          <Feature
            img={IMG.dumbbell}
            title="جلسه آشنایی رایگان"
            text="۱۸ دقیقه فعال‌سازی کل بدن تا حس مربی را بگیری."
            cta="شروع رایگان"
            onClick={() => router.push("/workout/free")}
          />
          <Feature
            img={IMG.bench}
            title={user.hasPlan ? "برنامه اختصاصی من" : "طراحی برنامه توسط مربی"}
            text={user.hasPlan ? "تقویم ۴ هفته، ورود به جلسه امروز." : "بعد اشتراک، قد و وزن و ۱۸ سوال دقیق."}
            cta={user.hasPlan ? "ورود به برنامه" : user.isPremium ? "شروع ارزیابی" : "ببین چطور کار می‌کنه"}
            onClick={() => router.push(user.hasPlan ? "/train" : user.isPremium ? "/assess" : "/subscribe")}
          />
          <Feature
            img={IMG.back}
            title="دانشنامه حرکات"
            text="سینه، پشت، پا، باسن — با توضیح مربی و تصویر واقعی."
            cta="کاوش"
            onClick={() => router.push("/explore")}
          />
        </div>
      </div>

      <div className="mt-5 overflow-hidden rounded-[24px]">
        <div className="flex gap-2 overflow-x-auto pb-1">
          {[
            { img: IMG.incline, t: "سینه" },
            { img: IMG.pullupM, t: "پشت" },
            { img: IMG.squat, t: "پا" },
            { img: IMG.womanTrain, t: "فرم" },
          ].map((x) => (
            <button key={x.t} className="relative h-36 w-28 shrink-0 overflow-hidden rounded-2xl" onClick={() => router.push("/explore")}>
              <img src={x.img} alt={x.t} className="h-full w-full object-cover" />
              <span className="absolute bottom-2 right-2 text-xs font-bold">{x.t}</span>
            </button>
          ))}
        </div>
      </div>

      {!user.isPremium && (
        <div className="relative mt-5 overflow-hidden rounded-[28px] fade-up-d3" style={{ minHeight: 170 }}>
          <img src={IMG.premium} alt="" className="absolute inset-0 h-full w-full object-cover" />
          <div className="absolute inset-0 bg-black/55" />
          <div className="relative p-5">
            <p className="badge">اشتراک ماهانه مایکت</p>
            <h3 className="mt-3 text-xl font-extrabold">وقتی آماده بودی، مربی کامل می‌شه</h3>
            <p className="mt-1 text-xs leading-6 text-white/70">
              برنامه غیررندوم، پیگیری ست‌به‌ست، دانلود PDF و آمار پیشرفت.
            </p>
            <RippleButton className="btn-lime mt-4" onClick={() => router.push("/subscribe")}>
              مشاهده اشتراک
            </RippleButton>
          </div>
        </div>
      )}

      <p className="mt-6 text-center text-[10px] text-white/30">FORJA · ساخته‌شده برای اندروید</p>
    </div>
  );
}

function Feature({
  img,
  title,
  text,
  cta,
  onClick,
}: {
  img: string;
  title: string;
  text: string;
  cta: string;
  onClick: () => void;
}) {
  return (
    <button onClick={onClick} className="card flex gap-3 p-2 text-right">
      <img src={img} alt="" className="h-20 w-20 rounded-2xl object-cover" />
      <div className="flex-1 py-1">
        <div className="text-sm font-extrabold">{title}</div>
        <div className="mt-1 text-[11px] leading-5 text-[var(--muted)]">{text}</div>
        <div className="mt-2 text-[11px] font-bold text-[var(--lime)]">{cta}</div>
      </div>
    </button>
  );
}

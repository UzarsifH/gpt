import { apiFetch } from "@/lib/api";
import { useEffect, useState } from "react";
import { useRouter } from "@/lib/nav";
import { RippleButton, useAuth } from "@/components/Providers";
import type { WorkoutPlanData } from "@/lib/types";
import { faNum } from "@/lib/format";
import { IMG } from "@/lib/media";

export default function PlanPage() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [plan, setPlan] = useState<WorkoutPlanData | null>(null);

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [loading, user, router]);

  useEffect(() => {
    void apiFetch("/api/plan")
      .then((r) => r.json())
      .then((d) => setPlan(d.plan));
  }, []);

  if (!plan) {
    return (
      <div className="px-5 pt-12">
        <h1 className="text-2xl font-extrabold">هنوز برنامه‌ای نیست</h1>
        <p className="mt-2 text-sm text-[var(--muted)]">اگر اشتراک داری، ارزیابی را کامل کن.</p>
        <RippleButton className="btn-lime mt-6 w-full" onClick={() => router.push(user?.isPremium ? "/assess" : "/subscribe")}>
          ادامه
        </RippleButton>
      </div>
    );
  }

  return (
    <div className="px-4 pb-8 pt-8">
      <div className="relative overflow-hidden rounded-3xl" style={{ height: 180 }}>
        <img src={IMG.glasses} alt="" className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent" />
        <div className="absolute bottom-4 right-4 left-4">
          <p className="chip">برنامه اختصاصی</p>
          <h1 className="mt-2 text-xl font-extrabold">{plan.title}</h1>
          <p className="text-[11px] text-white/70">{plan.subtitle}</p>
        </div>
      </div>

      <div className="mt-4 grid grid-cols-3 gap-2">
        <Stat n={faNum(plan.bmi)} l={plan.bmiLabel} />
        <Stat n={faNum(plan.daysPerWeek)} l="روز/هفته" />
        <Stat n={faNum(plan.weeks)} l="هفته" />
      </div>

      <div className="card mt-4 p-4">
        <p className="text-xs text-[var(--gold)]">پیش‌بینی مربی</p>
        <p className="mt-2 text-sm leading-7">{plan.estimatedChange}</p>
      </div>

      <h3 className="mt-5 text-sm font-bold">قوانین مربی</h3>
      <ul className="mt-2 space-y-2 text-sm leading-7 text-white/80">
        {plan.rules.map((r) => (
          <li key={r} className="card p-3">
            {r}
          </li>
        ))}
      </ul>

      <h3 className="mt-5 text-sm font-bold">تغذیه پیشنهادی</h3>
      <ul className="mt-2 space-y-2 text-sm leading-7 text-white/80">
        {plan.nutritionTips.map((r) => (
          <li key={r}>• {r}</li>
        ))}
      </ul>

      <RippleButton className="btn-lime btn-full mt-6" onClick={() => router.push("/train")}>
        شروع از تقویم تمرین
      </RippleButton>
      <RippleButton className="btn-ghost btn-full mt-2" onClick={() => router.push("/plan/print")}>
        دانلود / چاپ PDF برنامه
      </RippleButton>
    </div>
  );
}

function Stat({ n, l }: { n: string; l: string }) {
  return (
    <div className="card p-3 text-center">
      <div className="font-extrabold text-[var(--lime)]">{n}</div>
      <div className="text-[10px] text-[var(--muted)]">{l}</div>
    </div>
  );
}

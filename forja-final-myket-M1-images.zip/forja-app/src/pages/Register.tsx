import { apiFetch } from "@/lib/api";
import { useState } from "react";
import { useRouter } from "@/lib/nav";
import { IMG } from "@/lib/media";
import { RippleButton, useAuth } from "@/components/Providers";

export default function RegisterPage() {
  const router = useRouter();
  const { refresh } = useAuth();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit() {
    setBusy(true);
    setError("");
    const res = await apiFetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, phone, password }),
    });
    const data = await res.json();
    setBusy(false);
    if (!data.ok) {
      setError(data.error || "ثبت‌نام ناموفق");
      return;
    }
    await refresh();
    router.replace("/home");
  }

  return (
    <div className="px-5 pb-8 pt-10">
      <img src={IMG.logo} alt="" className="h-14 w-14 rounded-2xl" />
      <h1 className="mt-5 text-3xl font-extrabold">بساز، از صفر</h1>
      <p className="mt-2 text-sm leading-7 text-[var(--muted)]">
        فقط شماره و رمز. پیامک لازم نیست. پروفایلت همین‌جا ساخته می‌شه.
      </p>
      <div className="mt-8 space-y-3">
        <input className="field" placeholder="نام نمایشی (اختیاری)" value={name} onChange={(e) => setName(e.target.value)} />
        <input className="field" inputMode="tel" placeholder="شماره موبایل ۰۹..." value={phone} onChange={(e) => setPhone(e.target.value)} />
        <input className="field" type="password" placeholder="رمز عبور حداقل ۶ کاراکتر" value={password} onChange={(e) => setPassword(e.target.value)} />
        {error ? <p className="text-sm text-[var(--danger)]">{error}</p> : null}
        <RippleButton className="btn-lime btn-full" disabled={busy} onClick={() => void submit()}>
          {busy ? "در حال ساخت..." : "ساخت حساب فُرجا"}
        </RippleButton>
      </div>
      <button className="mt-6 w-full text-sm text-[var(--muted)]" onClick={() => router.push("/login")}>
        قبلاً ساختی؟ <span className="text-[var(--lime)]">ورود</span>
      </button>
    </div>
  );
}

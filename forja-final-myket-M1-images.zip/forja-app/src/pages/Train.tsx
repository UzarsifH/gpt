import { apiFetch } from "@/lib/api";
import { useEffect, useState } from "react";
import { useRouter } from "@/lib/nav";
import { useAuth } from "@/components/Providers";
import { RippleButton } from "@/components/Providers";
import type { PlannedDay, WorkoutPlanData } from "@/lib/types";
import { faNum } from "@/lib/format";
import { IMG } from "@/lib/media";

type Comp = { dayIndex: number };

export default function TrainPage() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [plan, setPlan] = useState<WorkoutPlanData | null>(null);
  const [planId, setPlanId] = useState<number | null>(null);
  const [free, setFree] = useState<PlannedDay | null>(null);
  const [completions, setCompletions] = useState<Comp[]>([]);
  const [week, setWeek] = useState(1);

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [loading, user, router]);

  useEffect(() => {
    void apiFetch("/api/plan")
      .then((r) => r.json())
      .then((d) => {
        setPlan(d.plan);
        setPlanId(d.planId ?? null);
        setFree(d.freeSession);
        setCompletions(d.completions || []);
      });
  }, []);

  const done = new Set(completions.map((c) => c.dayIndex));
  const days = plan?.days.filter((d) => d.week === week) ?? [];

  return (
    <div className="px-4 pb-6 pt-8">
      <h1 className="text-2xl font-extrabold">سالن تمرین</h1>
      <p className="mt-1 text-xs text-[var(--muted)]">هر روز را شروع کن، حرکت‌به‌حرکت جلو برو.</p>

      <div className="relative mt-4 overflow-hidden rounded-3xl" style={{ height: 150 }}>
        <img src={IMG.poseGym} alt="" className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-l from-black/80 to-black/20" />
        <div className="absolute bottom-4 right-4">
          <p className="text-sm font-extrabold">{plan ? plan.title : "هنوز برنامه اختصاصی نداری"}</p>
          <p className="text-[11px] text-white/70">{plan ? plan.subtitle : "اول جلسه رایگان را تست کن"}</p>
        </div>
      </div>

      <RippleButton className="btn-lime btn-full mt-4" onClick={() => router.push("/workout/free")}>
        شروع جلسه آشنایی
      </RippleButton>

      {!user?.isPremium && (
        <button className="card mt-3 w-full p-4 text-right" onClick={() => router.push("/subscribe")}>
          <div className="text-sm font-extrabold">قفل برنامه ۴ هفته‌ای</div>
          <div className="mt-1 text-xs text-[var(--muted)]">با اشتراک مایکت، مربی برای بدن خودت برنامه می‌چینه.</div>
        </button>
      )}

      {user?.isPremium && !plan && (
        <RippleButton className="btn-orange btn-full mt-3" onClick={() => router.push("/assess")}>
          ارزیابی بدن و ساخت برنامه
        </RippleButton>
      )}

      {plan && (
        <>
          <div className="mt-5 flex gap-2">
            {[1, 2, 3, 4].map((w) => (
              <button
                key={w}
                onClick={() => setWeek(w)}
                className={`flex-1 rounded-2xl py-2 text-xs font-extrabold ${week === w ? "bg-[var(--lime)] text-black" : "bg-white/5"}`}
              >
                هفته {faNum(w)}
              </button>
            ))}
          </div>
          <div className="mt-4 grid gap-2">
            {days.map((d) => {
              const locked = false;
              const isDone = done.has(d.index);
              return (
                <button
                  key={d.index}
                  disabled={locked}
                  onClick={() => router.push(`/workout/${d.index}?plan=${planId}`)}
                  className="card flex items-center justify-between p-3 text-right"
                >
                  <div>
                    <div className="text-sm font-extrabold">{d.title}</div>
                    <div className="text-[11px] text-[var(--muted)]">
                      {d.isRest ? "ریکاوری فعال" : `${faNum(d.exercises.length)} حرکت · ${faNum(d.durationMin)} دقیقه`}
                    </div>
                  </div>
                  <span className={`rounded-full px-3 py-1 text-[10px] font-bold ${isDone ? "bg-[var(--lime)] text-black" : "bg-white/10"}`}>
                    {isDone ? "انجام شد" : d.isRest ? "ریست" : "شروع"}
                  </span>
                </button>
              );
            })}
          </div>
          <button className="mt-4 w-full text-sm text-[var(--lime)]" onClick={() => router.push("/plan")}>
            مشاهده کامل برنامه و دانلود PDF
          </button>
        </>
      )}
    </div>
  );
}

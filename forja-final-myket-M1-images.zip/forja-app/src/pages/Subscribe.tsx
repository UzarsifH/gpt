import { apiFetch } from "@/lib/api";
import { useEffect, useState } from "react";
import { useRouter } from "@/lib/nav";
import { RippleButton, useAuth } from "@/components/Providers";
import { formatToman } from "@/lib/format";
import { IMG } from "@/lib/media";

export default function SubscribePage() {
  const { user, loading } = useAuth();
  const router = useRouter();
  const [price, setPrice] = useState(249000);

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [loading, user, router]);

  useEffect(() => {
    void apiFetch("/api/config")
      .then((r) => r.json())
      .then((d) => setPrice(d.monthlyPrice || 249000));
  }, []);

  if (user?.isPremium) {
    return (
      <div className="px-5 pt-12">
        <h1 className="text-2xl font-extrabold">اشتراک فعاله</h1>
        <p className="mt-2 text-sm text-[var(--muted)]">مربی در خدمتته. برو ارزیابی یا برنامه.</p>
        <RippleButton className="btn-lime btn-full mt-6" onClick={() => router.push(user.hasPlan ? "/train" : "/assess")}>
          ادامه مسیر
        </RippleButton>
      </div>
    );
  }

  return (
    <div>
      <div className="relative h-72">
        <img src={IMG.premium} alt="" className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#07070a] via-black/40 to-black/10" />
        <button className="absolute top-6 right-4 text-sm" onClick={() => router.back()}>
          بازگشت
        </button>
        <div className="absolute bottom-4 right-5 left-5">
          <p className="chip">پرداخت با مایکت</p>
          <h1 className="mt-2 text-3xl font-extrabold">مربی کامل فُرجا</h1>
        </div>
      </div>
      <div className="px-5 pb-8">
        <div className="card p-5">
          <p className="text-sm text-[var(--muted)]">اشتراک ماهانه</p>
          <p className="mt-1 text-3xl font-extrabold text-[var(--lime)]">{formatToman(price)}</p>
          <p className="mt-1 text-[11px] text-white/40">قابل تغییر از پنل ادمین · محصول درون‌برنامه‌ای مایکت</p>
        </div>
        <ul className="mt-5 space-y-3 text-sm leading-7">
          {[
            "ارزیابی دقیق قد، وزن و ۱۸ سوال مربی‌گونه",
            "برنامه ۴ هفته غیررندوم مخصوص بدن تو",
            "تمرین ست‌به‌ست داخل اپ با تایمر استراحت",
            "دانلود PDF شیک برنامه",
            "ثبت پیشرفت، وزن، کالری و مدال",
          ].map((x) => (
            <li key={x} className="flex gap-2">
              <span className="text-[var(--lime)]">●</span>
              {x}
            </li>
          ))}
        </ul>
        <RippleButton className="btn-lime btn-full mt-6" onClick={() => router.push("/pay")}>
          پرداخت با مایکت
        </RippleButton>
        <p className="mt-3 text-center text-[11px] leading-6 text-white/40">
          اپ را مجبور به خرید نمی‌کنیم. اول باشگاه را بگرد، وقتی آماده بودی مربی را باز کن.
        </p>
      </div>
    </div>
  );
}

import { apiFetch } from "@/lib/api";
import { useEffect, useState } from "react";
import { useRouter } from "@/lib/nav";
import { RippleButton, useAuth } from "@/components/Providers";
import { formatToman } from "@/lib/format";
import { hasNativeMyket, initializeMyket, launchMyketPurchase, type MyketPurchase } from "@/lib/myket";

 type Init = {
  paymentId: number;
  amount: number;
  sku: string;
  payload: string;
  packageName: string;
  rsaPublicKey: string;
  paymentMode: string;
};

export default function PayPage() {
  const { user, loading, refresh } = useAuth();
  const router = useRouter();
  const [init, setInit] = useState<Init | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [native, setNative] = useState(false);

  useEffect(() => {
    if (!loading && !user) router.replace("/login");
  }, [loading, user, router]);

  useEffect(() => {
    let alive = true;
    setNative(hasNativeMyket());
    void apiFetch("/api/payment/myket/init", { method: "POST" })
      .then((r) => r.json())
      .then(async (d) => {
        if (!alive) return;
        if (!d.ok) {
          setError(d.error || "خطا در شروع پرداخت");
          return;
        }
        setInit(d as Init);
        if (d.paymentMode !== "live" || !hasNativeMyket()) {
          setError("برای پرداخت واقعی، نسخه Android فُرجا را از مایکت اجرا کن.");
          return;
        }
        try {
          await initializeMyket();
          if (alive) setError("");
        } catch (e) {
          if (alive) setError(e instanceof Error ? e.message : "اتصال به مایکت ناموفق بود.");
        }
      })
      .catch(() => alive && setError("خطا در آماده‌سازی پرداخت مایکت"));
    return () => { alive = false; };
  }, []);

  async function verify(purchase: MyketPurchase) {
    if (!init) return;
    setBusy(true);
    try {
      const res = await apiFetch("/api/payment/myket/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ paymentId: init.paymentId, purchase }),
      });
      const data = await res.json();
      if (!data.ok) {
        setError(data.error || "تأیید پرداخت ناموفق بود؛ اشتراک فعال نشد.");
        return;
      }
      await refresh();
      router.replace("/assess");
    } catch {
      setError("ارتباط با تأییدکننده پرداخت قطع شد؛ اشتراک فعال نشد.");
    } finally {
      setBusy(false);
    }
  }

  async function pay() {
    if (!init || busy) return;
    setError("");
    if (!hasNativeMyket() || init.paymentMode !== "live") {
      setError("پرداخت واقعی فقط در نسخه Android و از طریق مایکت انجام می‌شود.");
      return;
    }
    setBusy(true);
    try {
      const purchase = await launchMyketPurchase(init.sku, init.payload);
      await verify(purchase);
    } catch (e) {
      setError(e instanceof Error ? e.message : "پرداخت انجام نشد؛ اشتراک فعال نشد.");
      setBusy(false);
    }
  }

  return (
    <div className="px-5 pt-10">
      <button className="text-sm text-white/50" onClick={() => router.back()}>بازگشت</button>
      <div className="card mt-5 overflow-hidden">
        <div className="bg-[#0b1b12] p-5">
          <p className="text-xs text-[#9be15d]">پرداخت واقعی درون‌برنامه‌ای مایکت</p>
          <h1 className="mt-2 text-2xl font-extrabold">اشتراک ماهانه فُرجا</h1>
          <p className="mt-1 text-[11px] text-white/50">تا تأیید موفق مایکت انجام نشود، اشتراک فعال نمی‌شود.</p>
        </div>
        <div className="p-5">
          {init ? <>
            <Row k="محصول" v="اشتراک ماهانه فُرجا" />
            <Row k="SKU" v={init.sku} />
            <Row k="پکیج" v={init.packageName || "ir.forja.app"} />
            <Row k="مبلغ" v={formatToman(init.amount)} />
            <Row k="حالت" v="پرداخت واقعی" />
          </> : <p className="text-sm text-[var(--muted)]">در حال اتصال به مایکت...</p>}
          {error ? <p className="mt-3 text-sm text-[var(--danger)]">{error}</p> : null}
          <RippleButton className="btn-lime btn-full mt-5" disabled={!init || busy || !native} onClick={pay}>
            {busy ? "در حال تأیید پرداخت..." : "پرداخت با مایکت"}
          </RippleButton>
          <p className="mt-3 text-[11px] leading-6 text-white/40">
            لغو یا شکست خرید، هیچ اشتراکی فعال نمی‌کند. فعال‌سازی فقط بعد از دریافت رسید خرید موفق از SDK مایکت انجام می‌شود.
          </p>
        </div>
      </div>
    </div>
  );
}

function Row({ k, v }: { k: string; v: string }) {
  return <div className="flex items-center justify-between border-b border-white/5 py-2 text-xs"><span className="text-white/40">{k}</span><span className="font-bold">{v}</span></div>;
}
